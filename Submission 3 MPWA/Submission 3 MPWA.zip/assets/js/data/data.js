export const competitions = [
    {
        "id": 2013,
        "name": "Série A",
        "code": "BSA"
    },
    {
        "id": 2016,
        "name": "Championship",
        "code": "ELC"
    },
    {
        "id": 2021,
        "name": "Premier League",
        "code": "PL"
    },
    {
        "id": 2018,
        "name": "European Championship",
        "code": "EC"
    },
    {
        "id": 2001,
        "name": "UEFA Champions League",
        "code": "CL"
    },
    {
        "id": 2015,
        "name": "Ligue 1",
        "code": "FL1"
    },
    {
        "id": 2002,
        "name": "Bundesliga",
        "code": "BL1"
    },
    {
        "id": 2019,
        "name": "Serie A",
        "code": "SA"
    },
    {
        "id": 2003,
        "name": "Eredivisie",
        "code": "DED"
    },
    {
        "id": 2017,
        "name": "Primeira Liga",
        "code": "PPL"
    },
    {
        "id": 2014,
        "name": "Primera Division",
        "code": "PD"
    },
    {
        "id": 2000,
        "name": "FIFA World Cup",
        "code": "WC"
    }
];