import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./styles/main.css";
import main from "./script/main.js";

main();